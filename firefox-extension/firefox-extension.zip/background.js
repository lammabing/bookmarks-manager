// Background service worker for the Firefox bookmark extension

// API base URL - adjust this to match your server
const API_BASE_URL = 'http://localhost:5170/api';

// NOTE: For Firefox compatibility, use the browser.* namespace instead of chrome.*
// You may use a polyfill if you want to support both Chrome and Firefox.

browser.runtime.onInstalled.addListener(() => {
  browser.contextMenus.create({
    id: "add-bookmark",
    title: "Add page to Bookmarks Manager",
    contexts: ["page"]
  });
});

browser.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "add-bookmark" && tab) {
    browser.scripting.executeScript({
      target: {tabId: tab.id},
      func: () => {
        browser.runtime.sendMessage({
          action: "add_bookmark_from_context_menu",
          url: window.location.href,
          title: document.title
        });
      }
    });
  }
});

// Listen for messages from popup and content scripts
browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Firefox background received message:', request);

  if (request.action === 'get_auth_token') {
    // Retrieve stored token
    browser.storage.local.get(['authToken', 'user']).then((result) => {
      sendResponse({
        token: result.authToken || null,
        user: result.user || null
      });
    });
    return true; // Keep message channel open for async response
  }

  if (request.action === 'set_auth_token') {
    // Store auth token and user info
    browser.storage.local.set({
      authToken: request.token,
      user: request.user
    }).then(() => {
      console.log('Auth token stored successfully');
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'clear_auth_token') {
    // Clear auth token and user info
    browser.storage.local.remove(['authToken', 'user']).then(() => {
      console.log('Auth token cleared');
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'add_bookmark') {
    // Handle adding bookmark from popup
    addBookmark(request.bookmarkData, request.token)
      .then(response => sendResponse({ success: true, data: response }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'verify_token') {
    // Verify if token is still valid
    verifyToken(request.token)
      .then(user => sendResponse({ success: true, user }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Handle the original context menu add_bookmark action
  if (request.action === "add_bookmark_from_context_menu") {
    // Send bookmark to backend API (for context menu)
    browser.storage.local.get(["authToken"]).then((result) => {
      const token = result.authToken;
      fetch(`${API_BASE_URL}/bookmarks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-auth-token': token } : {})
        },
        body: JSON.stringify({ title: request.title, url: request.url })
      })
        .then(res => {
          if (!res.ok) throw new Error('Failed to add bookmark');
          return res.json();
        })
        .then(() => {
          // Optionally notify the user or update UI
        })
        .catch((error) => {
          console.error('Error adding bookmark:', error);
          // Optionally handle error
        });
    });
  }
});

// Function to add bookmark
async function addBookmark(bookmarkData, token) {
  try {
    const response = await fetch(`${API_BASE_URL}/bookmarks`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': token
      },
      body: JSON.stringify(bookmarkData)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to add bookmark');
    }

    return await response.json();
  } catch (error) {
    console.error('Error adding bookmark:', error);
    throw error;
  }
}

// Function to verify token
async function verifyToken(token) {
  try {
    const response = await fetch(`${API_BASE_URL}/users/me`, {
      method: 'GET',
      headers: {
        'x-auth-token': token
      }
    });

    if (!response.ok) {
      throw new Error('Token is invalid or expired');
    }

    return await response.json();
  } catch (error) {
    console.error('Error verifying token:', error);
    throw error;
  }
}

// Listen for extension startup
browser.runtime.onStartup.addListener(() => {
  console.log('Bookmark extension started');
});
